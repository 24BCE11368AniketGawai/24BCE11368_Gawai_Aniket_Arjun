package com.ocms.dto;

import lombok.Data;

@Data
public class StudentResponse {

    private String studentId;

    private String name;

    private String email;

    private String mobile;
}