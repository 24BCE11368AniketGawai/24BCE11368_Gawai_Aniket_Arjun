package com.ocms.dto;

import lombok.Data;

@Data
public class StudentRequest {

    private String name;

    private String email;

    private String mobile;

    private String departmentId;

    private String profileId;
}