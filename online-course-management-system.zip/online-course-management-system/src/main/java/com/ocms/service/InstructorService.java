package com.ocms.service;

import com.ocms.model.Instructor;
import java.util.List;

public interface InstructorService {

    Instructor saveInstructor(Instructor instructor);

    List<Instructor> getAllInstructors();

    Instructor getInstructorById(String id);

    Instructor updateInstructor(String id, Instructor instructor);

    void deleteInstructor(String id);
}