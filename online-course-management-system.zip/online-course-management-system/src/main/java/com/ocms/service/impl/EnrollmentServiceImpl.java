package com.ocms.service.impl;

import com.ocms.exception.ResourceNotFoundException;
import com.ocms.model.Enrollment;
import com.ocms.repository.EnrollmentRepository;
import com.ocms.service.EnrollmentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;

    public EnrollmentServiceImpl(
            EnrollmentRepository enrollmentRepository) {

        this.enrollmentRepository = enrollmentRepository;
    }

    @Override
    public Enrollment saveEnrollment(
            Enrollment enrollment) {

        return enrollmentRepository.save(enrollment);
    }

    @Override
    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }

   @Override
public Enrollment getEnrollmentById(String id) {

    return enrollmentRepository.findById(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Enrollment not found with id : " + id));
}

    @Override
    public Enrollment updateEnrollment(
            String id,
            Enrollment enrollment) {

        Enrollment existing =
                enrollmentRepository.findById(id).orElse(null);

        if(existing != null){

            existing.setStudentId(
                    enrollment.getStudentId());

            existing.setCourseId(
                    enrollment.getCourseId());

            existing.setEnrollmentDate(
                    enrollment.getEnrollmentDate());

            existing.setStatus(
                    enrollment.getStatus());

            return enrollmentRepository.save(existing);
        }

        return null;
    }

    @Override
    public void deleteEnrollment(String id) {
        enrollmentRepository.deleteById(id);
    }
}