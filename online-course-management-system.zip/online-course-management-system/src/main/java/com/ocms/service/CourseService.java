package com.ocms.service;

import com.ocms.model.Course;
import java.util.List;

public interface CourseService {

    Course saveCourse(Course course);

    List<Course> getAllCourses();

    Course getCourseById(String id);

    Course updateCourse(String id, Course course);

    void deleteCourse(String id);
}