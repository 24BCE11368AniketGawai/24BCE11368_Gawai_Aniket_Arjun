package com.ocms.service;

import com.ocms.model.Student;
import java.util.List;

public interface StudentService {

    Student saveStudent(Student student);

    List<Student> getAllStudents();

    Student getStudentById(String id);

    Student updateStudent(String id, Student student);

    void deleteStudent(String id);
}