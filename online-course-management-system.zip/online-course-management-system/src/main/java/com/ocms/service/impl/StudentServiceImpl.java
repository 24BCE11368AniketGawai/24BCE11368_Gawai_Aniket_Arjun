package com.ocms.service.impl;

import com.ocms.exception.ResourceNotFoundException;
import com.ocms.model.Student;
import com.ocms.repository.StudentRepository;
import com.ocms.service.StudentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

   @Override
public Student getStudentById(String id) {

    return studentRepository.findById(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Student not found with id : " + id));
}

    @Override
    public Student updateStudent(String id, Student student) {

        Student existingStudent =
                studentRepository.findById(id).orElse(null);

        if (existingStudent != null) {

            existingStudent.setName(student.getName());
            existingStudent.setEmail(student.getEmail());
            existingStudent.setMobile(student.getMobile());
            existingStudent.setDepartmentId(student.getDepartmentId());
            existingStudent.setProfileId(student.getProfileId());

            return studentRepository.save(existingStudent);
        }

        return null;
    }

    @Override
    public void deleteStudent(String id) {
        studentRepository.deleteById(id);
    }
}