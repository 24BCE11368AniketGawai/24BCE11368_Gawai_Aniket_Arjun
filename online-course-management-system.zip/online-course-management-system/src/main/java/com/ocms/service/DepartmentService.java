package com.ocms.service;

import com.ocms.model.Department;
import java.util.List;

public interface DepartmentService {

    Department saveDepartment(Department department);

    List<Department> getAllDepartments();

    Department getDepartmentById(String id);

    Department updateDepartment(String id, Department department);

    void deleteDepartment(String id);
}