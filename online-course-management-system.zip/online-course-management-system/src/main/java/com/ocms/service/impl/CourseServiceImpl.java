package com.ocms.service.impl;

import com.ocms.exception.ResourceNotFoundException;
import com.ocms.model.Course;
import com.ocms.repository.CourseRepository;
import com.ocms.service.CourseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;

    public CourseServiceImpl(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    @Override
    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

   @Override
public Course getCourseById(String id) {

    return courseRepository.findById(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Course not found with id : " + id));
}

    @Override
    public Course updateCourse(String id, Course course) {

        Course existing =
                courseRepository.findById(id).orElse(null);

        if(existing != null){

            existing.setCourseName(course.getCourseName());
            existing.setDescription(course.getDescription());
            existing.setDuration(course.getDuration());
            existing.setFees(course.getFees());
            existing.setInstructorId(course.getInstructorId());
            existing.setDepartmentId(course.getDepartmentId());

            return courseRepository.save(existing);
        }

        return null;
    }

    @Override
    public void deleteCourse(String id) {
        courseRepository.deleteById(id);
    }
}