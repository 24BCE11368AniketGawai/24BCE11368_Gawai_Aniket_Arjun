package com.ocms.service.impl;

import com.ocms.exception.ResourceNotFoundException;
import com.ocms.model.Department;
import com.ocms.repository.DepartmentRepository;
import com.ocms.service.DepartmentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentServiceImpl(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    @Override
    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    @Override
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @Override
public Department getDepartmentById(String id) {

    return departmentRepository.findById(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Department not found with id : " + id));
}
    @Override
    public Department updateDepartment(String id, Department department) {

        Department existingDepartment =
                departmentRepository.findById(id).orElse(null);

        if(existingDepartment != null) {

            existingDepartment.setDepartmentName(
                    department.getDepartmentName());

            existingDepartment.setHodName(
                    department.getHodName());

            return departmentRepository.save(existingDepartment);
        }

        return null;
    }

    @Override
    public void deleteDepartment(String id) {
        departmentRepository.deleteById(id);
    }
}