package com.ocms.service.impl;

import com.ocms.exception.ResourceNotFoundException;
import com.ocms.model.Instructor;
import com.ocms.repository.InstructorRepository;
import com.ocms.service.InstructorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InstructorServiceImpl implements InstructorService {

    private final InstructorRepository instructorRepository;

    public InstructorServiceImpl(InstructorRepository instructorRepository) {
        this.instructorRepository = instructorRepository;
    }

    @Override
    public Instructor saveInstructor(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    @Override
    public List<Instructor> getAllInstructors() {
        return instructorRepository.findAll();
    }

   @Override
public Instructor getInstructorById(String id) {

    return instructorRepository.findById(id)
            .orElseThrow(() ->
                    new ResourceNotFoundException(
                            "Instructor not found with id : " + id));
}

    @Override
    public Instructor updateInstructor(String id, Instructor instructor) {

        Instructor existingInstructor =
                instructorRepository.findById(id).orElse(null);

        if(existingInstructor != null){

            existingInstructor.setInstructorName(
                    instructor.getInstructorName());

            existingInstructor.setEmail(
                    instructor.getEmail());

            existingInstructor.setSpecialization(
                    instructor.getSpecialization());

            existingInstructor.setDepartmentId(
                    instructor.getDepartmentId());

            return instructorRepository.save(existingInstructor);
        }

        return null;
    }

    @Override
    public void deleteInstructor(String id) {
        instructorRepository.deleteById(id);
    }
}