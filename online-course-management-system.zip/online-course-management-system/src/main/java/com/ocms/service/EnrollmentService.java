package com.ocms.service;

import com.ocms.model.Enrollment;
import java.util.List;

public interface EnrollmentService {

    Enrollment saveEnrollment(Enrollment enrollment);

    List<Enrollment> getAllEnrollments();

    Enrollment getEnrollmentById(String id);

    Enrollment updateEnrollment(String id, Enrollment enrollment);

    void deleteEnrollment(String id);
}