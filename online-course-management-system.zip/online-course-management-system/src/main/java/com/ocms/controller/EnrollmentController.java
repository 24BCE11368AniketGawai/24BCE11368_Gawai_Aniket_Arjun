package com.ocms.controller;

import com.ocms.model.Enrollment;
import com.ocms.service.EnrollmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    public EnrollmentController(
            EnrollmentService enrollmentService) {

        this.enrollmentService = enrollmentService;
    }

    @PostMapping
    public Enrollment createEnrollment(
            @RequestBody Enrollment enrollment) {

        return enrollmentService.saveEnrollment(enrollment);
    }

    @GetMapping
    public List<Enrollment> getAllEnrollments() {

        return enrollmentService.getAllEnrollments();
    }

    @GetMapping("/{id}")
    public Enrollment getEnrollmentById(
            @PathVariable String id) {

        return enrollmentService.getEnrollmentById(id);
    }

    @PutMapping("/{id}")
    public Enrollment updateEnrollment(
            @PathVariable String id,
            @RequestBody Enrollment enrollment) {

        return enrollmentService.updateEnrollment(
                id,
                enrollment);
    }

    @DeleteMapping("/{id}")
    public String deleteEnrollment(
            @PathVariable String id) {

        enrollmentService.deleteEnrollment(id);

        return "Enrollment Deleted Successfully";
    }
}