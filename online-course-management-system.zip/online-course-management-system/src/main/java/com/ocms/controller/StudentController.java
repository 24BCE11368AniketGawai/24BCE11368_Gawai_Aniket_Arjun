package com.ocms.controller;

import com.ocms.dto.StudentRequest;
import com.ocms.dto.StudentResponse;
import com.ocms.model.Student;
import com.ocms.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping
public StudentResponse createStudent(
        @RequestBody StudentRequest request) {

    Student student = new Student();

    student.setName(request.getName());
    student.setEmail(request.getEmail());
    student.setMobile(request.getMobile());
    student.setDepartmentId(request.getDepartmentId());
    student.setProfileId(request.getProfileId());

    Student savedStudent =
            studentService.saveStudent(student);

    return convertToResponse(savedStudent);
}

    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable String id) {
        return studentService.getStudentById(id);
    }

    @PutMapping("/{id}")
    public Student updateStudent(
            @PathVariable String id,
            @RequestBody Student student) {

        return studentService.updateStudent(id, student);
    }

    private StudentResponse convertToResponse(Student student) {

    StudentResponse response = new StudentResponse();

    response.setStudentId(student.getStudentId());
    response.setName(student.getName());
    response.setEmail(student.getEmail());
    response.setMobile(student.getMobile());

    return response;
}
}