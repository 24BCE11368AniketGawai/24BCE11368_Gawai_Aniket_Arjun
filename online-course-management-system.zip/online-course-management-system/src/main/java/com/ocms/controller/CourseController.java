package com.ocms.controller;

import com.ocms.model.Course;
import com.ocms.service.CourseService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PostMapping
    public Course createCourse(
            @RequestBody Course course) {

        return courseService.saveCourse(course);
    }

    @GetMapping
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/{id}")
    public Course getCourseById(
            @PathVariable String id) {

        return courseService.getCourseById(id);
    }

    @PutMapping("/{id}")
    public Course updateCourse(
            @PathVariable String id,
            @RequestBody Course course) {

        return courseService.updateCourse(id, course);
    }

    @DeleteMapping("/{id}")
    public String deleteCourse(
            @PathVariable String id) {

        courseService.deleteCourse(id);

        return "Course Deleted Successfully";
    }
}