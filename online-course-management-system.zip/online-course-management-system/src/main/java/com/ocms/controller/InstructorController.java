package com.ocms.controller;

import com.ocms.model.Instructor;
import com.ocms.service.InstructorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/instructors")
public class InstructorController {

    private final InstructorService instructorService;

    public InstructorController(
            InstructorService instructorService) {

        this.instructorService = instructorService;
    }

    @PostMapping
    public Instructor createInstructor(
            @RequestBody Instructor instructor) {

        return instructorService.saveInstructor(instructor);
    }

    @GetMapping
    public List<Instructor> getAllInstructors() {

        return instructorService.getAllInstructors();
    }

    @GetMapping("/{id}")
    public Instructor getInstructorById(
            @PathVariable String id) {

        return instructorService.getInstructorById(id);
    }

    @PutMapping("/{id}")
    public Instructor updateInstructor(
            @PathVariable String id,
            @RequestBody Instructor instructor) {

        return instructorService.updateInstructor(
                id,
                instructor);
    }

    @DeleteMapping("/{id}")
    public String deleteInstructor(
            @PathVariable String id) {

        instructorService.deleteInstructor(id);

        return "Instructor Deleted Successfully";
    }
}