# Online Course Management System

## Project Overview

The Online Course Management System is a backend application developed using Java, Spring Boot, and MongoDB. The system allows administrators to manage departments, students, instructors, courses, and enrollments through REST APIs.

The project demonstrates CRUD operations, MongoDB integration, RESTful API development, exception handling, Swagger documentation, and layered architecture using Controller, Service, and Repository patterns.

---

## Technologies Used

* Java 24
* Spring Boot 3.x
* MongoDB
* Maven
* Swagger OpenAPI
* Lombok
* Thunder Client / Postman
* VS Code

---

## Project Structure

src/main/java/com/ocms

* controller
* service
* service/impl
* repository
* model
* dto
* exception
* resources
* OcmsApplication.java

---

## Modules

### Department Module

* Create Department
* View Department
* Update Department
* Delete Department

### Student Module

* Create Student
* View Student
* Update Student
* Delete Student

### Instructor Module

* Create Instructor
* View Instructor
* Update Instructor
* Delete Instructor

### Course Module

* Create Course
* View Course
* Update Course
* Delete Course

### Enrollment Module

* Create Enrollment
* View Enrollment
* Update Enrollment
* Delete Enrollment

---

## Database

Database Name:

online_course_db

Collections:

* departments
* students
* instructors
* courses
* enrollments

---

## API Endpoints

### Department APIs

* POST /api/departments
* GET /api/departments
* GET /api/departments/{id}
* PUT /api/departments/{id}
* DELETE /api/departments/{id}

### Student APIs

* POST /api/students
* GET /api/students
* GET /api/students/{id}
* PUT /api/students/{id}
* DELETE /api/students/{id}

### Instructor APIs

* POST /api/instructors
* GET /api/instructors
* GET /api/instructors/{id}
* PUT /api/instructors/{id}
* DELETE /api/instructors/{id}

### Course APIs

* POST /api/courses
* GET /api/courses
* GET /api/courses/{id}
* PUT /api/courses/{id}
* DELETE /api/courses/{id}

### Enrollment APIs

* POST /api/enrollments
* GET /api/enrollments
* GET /api/enrollments/{id}
* PUT /api/enrollments/{id}
* DELETE /api/enrollments/{id}

---

## Features Implemented

* CRUD Operations
* MongoDB Integration
* Spring Data MongoDB
* Exception Handling
* Swagger Documentation
* DTO Layer
* REST APIs
* Layered Architecture

---

## Swagger Documentation

Open:

http://localhost:8082/swagger-ui/index.html

---

## Run the Project

1. Start MongoDB
2. Open project folder
3. Run:

mvnw.cmd spring-boot:run

4. Open Swagger UI

http://localhost:8082/swagger-ui/index.html

---

## Author

Aniket Gawai
24BCE11368
VIT Bhopal University
